# PerCare Portal – الكود المصدري الكامل

## 📁 هيكل المشروع

```
percare-FULL-SOURCE/
├── frontend/                    # واجهة المستخدم (React 18 + Vite + Tailwind)
│   ├── src/
│   │   ├── App.jsx              # التوجيه الرئيسي
│   │   ├── main.jsx             # نقطة الدخول
│   │   ├── index.css            # الأنماط العامة
│   │   ├── layouts/
│   │   │   └── PortalLayout.jsx # الشريط الجانبي + الرأس + RTL
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx                      # لوحة التحكم
│   │   │   └── percare/
│   │   │       ├── PerCareRequestsListPage.jsx    # قائمة الطلبات
│   │   │       └── PerCareRequestDetailsPage.jsx  # تفاصيل الطلب
│   │   ├── components/
│   │   │   ├── percare/         # مكونات PerCare
│   │   │   └── ui/              # مكونات عامة
│   │   ├── contexts/            # React Context
│   │   ├── hooks/               # Custom Hooks
│   │   └── data/                # بيانات Mock
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── .env.example
│
├── backend/                     # الخادم (Node.js + Express + PostgreSQL)
│   ├── app.js                   # نقطة دخول الخادم
│   ├── package.json
│   ├── Dockerfile
│   ├── config/index.js          # الإعدادات
│   ├── db/
│   │   ├── pool.js              # اتصال قاعدة البيانات
│   │   ├── migrations/          # SQL Migrations
│   │   └── seed.js              # بيانات أولية
│   ├── modules/percare/
│   │   ├── controllers/         # معالجة الطلبات
│   │   ├── services/            # منطق الأعمال
│   │   ├── repositories/        # طبقة قاعدة البيانات
│   │   ├── routes/              # تعريف API
│   │   ├── middleware/          # المصادقة والحماية
│   │   ├── scheduler/           # جدولة المهام
│   │   ├── validators/          # التحقق من البيانات
│   │   └── utils/               # أدوات مساعدة
│   └── tests/                   # اختبارات
│
└── docker-compose.yml           # تشغيل بأمر واحد
```

---

## 🚀 تشغيل سريع بـ Docker

```bash
# 1. فك الضغط
unzip percare-FULL-SOURCE.zip
cd percare-FULL-SOURCE

# 2. إنشاء ملف البيئة
cp backend/.env.example backend/.env
# عدّل backend/.env حسب إعداداتك

# 3. تشغيل الكل
docker compose up -d --build

# الواجهة:  http://localhost:80
# API:       http://localhost:3000/api/percare
# صحة:       http://localhost:3000/health
```

---

## 🛠️ تشغيل يدوي

### Backend
```bash
cd backend
npm install
cp .env.example .env
# عدّل .env بمعلومات PostgreSQL

# تشغيل Migration
psql -U postgres -d your_db -f db/migrations/001_create_percare_tables.sql

# بيانات أولية (اختياري)
node db/seed.js

# تشغيل الخادم
npm run dev       # وضع التطوير
npm start         # وضع الإنتاج
```

### Frontend
```bash
cd frontend
npm install
cp .env.example .env
# عدّل VITE_API_BASE_URL

npm run dev       # وضع التطوير  → http://localhost:5173
npm run build     # بناء للإنتاج → مجلد dist/
npm run preview   # معاينة البناء → http://localhost:4173
```

---

## 🔌 API Endpoints

| Method | Endpoint | الوصف |
|--------|----------|-------|
| `POST` | `/api/percare/requests` | إنشاء طلب جديد |
| `GET` | `/api/percare/requests` | قائمة الطلبات |
| `GET` | `/api/percare/requests/:id` | تفاصيل طلب |
| `GET` | `/api/percare/requests/:id/slots` | جدول الجلسات |
| `GET` | `/api/percare/requests/:id/stats` | إحصائيات |
| `POST` | `/api/percare/requests/:id/cancel` | إلغاء طلب |
| `POST` | `/api/percare/requests/:id/recalculate` | إعادة حساب |
| `PUT` | `/api/percare/slots/:id/status` | تحديث حالة جلسة |
| `GET` | `/api/percare/slots/:id/logs` | سجل التدقيق |
| `POST` | `/api/percare/slots/bulk-update` | تحديث جماعي |
| `POST` | `/api/percare/jobs/mark-overdue` | تشغيل مهمة التأخير |

---

## 🔒 المصادقة (JWT)

عدّل `backend/modules/percare/middleware/percareAuth.js`:

```js
const jwt = require('jsonwebtoken');

const requireAuth = async (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
};
```

---

## 📦 دمج مع بورتال موجود

### Backend
```js
// في app.js الخاص بك
app.use('/api/percare', require('./modules/percare/routes/percare.routes'));
```

### Frontend
```jsx
// في App.jsx الخاص بك
import PerCareModule from './components/percare/PerCareModule';
<Route path="/percare/*" element={<PerCareModule />} />
```

---

## 🗄️ متغيرات البيئة (backend/.env)

```env
NODE_ENV=production
PORT=3000

DB_HOST=localhost
DB_PORT=5432
DB_NAME=homecare_db
DB_USER=postgres
DB_PASSWORD=your_password
DB_POOL_MAX=10

JWT_SECRET=your_jwt_secret_here
JWT_EXPIRES_IN=8h

CORS_ORIGIN=http://localhost:5173
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX=100

DELAY_JOB_CRON=0 1 * * *
CRON_TIMEZONE=Asia/Riyadh
```
