# PerCare Module — دليل التشغيل الكامل
> وحدة إدارة طلبات الرعاية المنزلية المجدولة

---

## 🏗️ هيكل المشروع

```
percare-v3-package/
├── frontend/          ← React 18 + Vite + Tailwind (واجهة عربية RTL)
│   ├── src/
│   │   ├── api/
│   │   │   ├── percare.api.js    ← طبقة الـ API (Mock ↔ حقيقي)
│   │   │   └── mockData.js       ← بيانات وهمية للتطوير
│   │   ├── pages/percare/
│   │   │   ├── PerCareRequestsListPage.jsx   ← صفحة قائمة الطلبات
│   │   │   └── PerCareRequestDetailsPage.jsx ← صفحة تفاصيل الطلب
│   │   ├── components/percare/   ← مكونات قابلة لإعادة الاستخدام
│   │   ├── layouts/PortalLayout.jsx  ← Sidebar + Header
│   │   └── contexts/ToastContext.jsx ← إشعارات
│   ├── .env.example       ← متغيرات البيئة (للتطوير)
│   └── .env.production    ← متغيرات البيئة (للإنتاج)
│
├── backend/           ← Node.js + Express + PostgreSQL
│   ├── app.js             ← نقطة الدخول
│   ├── config/            ← إعدادات DB, JWT, CORS
│   ├── db/
│   │   ├── migrations/001_create_percare_tables.sql
│   │   └── seed.js        ← بيانات تجريبية
│   ├── modules/percare/
│   │   ├── controllers/   ← 5 controllers
│   │   ├── services/      ← 7 services
│   │   ├── repositories/  ← 4 repositories
│   │   ├── routes/        ← 11 endpoints
│   │   ├── middleware/    ← Auth, Rate Limit, Error Handler
│   │   ├── scheduler/     ← Cron job للمتأخرات
│   │   └── validators/    ← Joi validation
│   └── tests/             ← 4 ملفات اختبار
│
└── docker-compose.yml ← يشغل DB + Backend بأمر واحد
```

---

## 🚀 طريقة التشغيل

### الطريقة 1: Docker (الأسرع — أمر واحد)

```bash
# تشغيل قاعدة البيانات والـ Backend
docker compose up -d --build

# تطبيق الـ Migrations
docker compose exec backend node -e "
  const { pool } = require('./db/pool');
  const fs = require('fs');
  pool.query(fs.readFileSync('./db/migrations/001_create_percare_tables.sql', 'utf8'))
    .then(() => console.log('✅ Migration done'))
    .catch(console.error)
"

# تشغيل الـ Frontend
cd frontend && npm install && npm run dev
```

### الطريقة 2: يدوي

#### أ. تشغيل قاعدة البيانات
```bash
# إنشاء قاعدة البيانات
psql -U postgres -c "CREATE DATABASE homecare_db;"

# تطبيق الـ Schema
psql -U postgres -d homecare_db -f backend/db/migrations/001_create_percare_tables.sql
```

#### ب. تشغيل الـ Backend
```bash
cd backend
cp .env.example .env
# عدّل .env ببيانات قاعدة البيانات الخاصة بك

npm install
npm run dev      # تطوير (مع hot reload)
# أو
npm start        # إنتاج
```

#### ج. تشغيل الـ Frontend
```bash
cd frontend
cp .env.example .env
# التعديل المطلوب في .env:
#   VITE_USE_MOCK=false
#   VITE_API_BASE_URL=http://localhost:3000/api/percare

npm install
npm run dev      # يعمل على http://localhost:5173
```

---

## 🔌 وضع Mock vs وضع حقيقي

| الإعداد | النتيجة |
|---------|---------|
| `VITE_USE_MOCK=true` (الافتراضي) | بيانات وهمية — لا يحتاج سيرفر |
| `VITE_USE_MOCK=false` | يتصل بالـ Backend الحقيقي |

---

## 🔗 API Endpoints (الـ Backend)

| Method | Endpoint | الوصف |
|--------|----------|-------|
| GET | `/api/percare/requests` | قائمة الطلبات (بحث + فلترة) |
| POST | `/api/percare/requests` | إنشاء طلب جديد |
| GET | `/api/percare/requests/:id` | تفاصيل طلب |
| GET | `/api/percare/requests/:id/slots` | الجدول الأسبوعي |
| GET | `/api/percare/requests/:id/stats` | إحصائيات KPI |
| POST | `/api/percare/requests/:id/recalculate` | إعادة حساب الجدول |
| POST | `/api/percare/requests/:id/cancel` | إلغاء الطلب |
| PUT | `/api/percare/slots/:id/status` | تحديث حالة جلسة |
| GET | `/api/percare/slots/:id/logs` | سجل تدقيق الجلسة |
| POST | `/api/percare/slots/bulk-update` | تحديث جماعي |
| POST | `/api/percare/jobs/mark-overdue` | تشغيل مهمة المتأخرات |

---

## 🔧 دمج الوحدة في الداشبورد الحالي

### 1. إضافة مسار الـ Backend
```js
// في app.js الخاص بك
app.use('/api/percare', require('./modules/percare/routes/percare.routes'));
```

### 2. إضافة مسارات الـ Frontend (React Router)
```jsx
// في App.jsx أو router الخاص بك
import PerCareRequestsListPage   from './pages/percare/PerCareRequestsListPage'
import PerCareRequestDetailsPage from './pages/percare/PerCareRequestDetailsPage'

<Route path="/percare/requests"     element={<PerCareRequestsListPage />} />
<Route path="/percare/requests/:id" element={<PerCareRequestDetailsPage />} />
```

### 3. ربط المصادقة
يدعم الـ frontend توكن من أي من المفاتيح التالية:
- `localStorage.homecare_token`
- `localStorage.percare_token`  
- `localStorage.token`
- `sessionStorage.token`

لا تحتاج تعديلاً إضافياً إذا كان نظامك يستخدم أياً منها.

---

## 🧪 الاختبارات
```bash
cd backend
npm test
```

---

## 📦 المتطلبات
- **Node.js**: 18+
- **PostgreSQL**: 14+
- **npm**: 8+
- **Docker**: (اختياري)
