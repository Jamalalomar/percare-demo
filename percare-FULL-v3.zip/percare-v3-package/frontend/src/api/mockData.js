/**
 * بيانات وهمية للتطوير والعرض التجريبي
 * تُستخدم فقط عندما VITE_USE_MOCK=true (الافتراضي)
 * في الإنتاج: اضبط VITE_USE_MOCK=false
 */

// ─── مساعدات ──────────────────────────────────────────────────────────────
function addDays(dateStr, n) {
  const d = new Date(dateStr); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10)
}

function distribute(freq, days = 7) {
  const arr = Array(days).fill(0)
  for (let i = 0; i < freq; i++) arr[Math.floor(i * days / freq)]++
  return arr
}

const TIMES = ['08:00', '08:30', '09:00', '10:00', '10:30', '11:00', '14:00', '15:00', '16:00']
const NOW   = new Date()

function makeSlots(reqId, startDate, frequency, totalWeeks) {
  const sessionDays = []
  const dist = distribute(frequency, 7)
  dist.forEach((count, dayIdx) => { for (let c = 0; c < count; c++) sessionDays.push({ dayIdx, timeIdx: c }) })

  const slots = []
  for (let w = 0; w < totalWeeks; w++) {
    for (const { dayIdx, timeIdx } of sessionDays) {
      const date = addDays(startDate, w * 7 + dayIdx)
      const past = new Date(date) < NOW
      const status = past ? (Math.random() > 0.15 ? 'COMPLETED' : 'DELAYED') : 'PENDING'
      slots.push({
        id: `${reqId}-w${w + 1}-d${dayIdx}-t${timeIdx}`,
        requestId: reqId,
        weekNumber: w + 1,
        dayOfWeek: dayIdx,
        date,
        time: TIMES[(dayIdx * 2 + timeIdx) % TIMES.length],
        status,
        notes: status === 'DELAYED' ? 'لم يتمكن المريض من الحضور' : '',
        logs: [],
      })
    }
  }
  return slots
}

// ─── بيانات المرضى ─────────────────────────────────────────────────────────
const PATIENTS = [
  { name: 'أحمد محمد العمري',    extId: 'PT-0091', gender: 'M', age: 68 },
  { name: 'فاطمة علي الزهراني', extId: 'PT-0134', gender: 'F', age: 54 },
  { name: 'خالد سعد الراشدي',   extId: 'PT-0217', gender: 'M', age: 72 },
  { name: 'مريم حمد البلوي',    extId: 'PT-0082', gender: 'F', age: 61 },
  { name: 'عمر عبدالله الغامدي',extId: 'PT-0305', gender: 'M', age: 79 },
  { name: 'سارة يوسف العتيبي',  extId: 'PT-0166', gender: 'F', age: 45 },
]

const PLANS = [
  { name: 'الرعاية اليومية الشاملة',   services: ['تمريض يومي', 'قياس ضغط', 'تغيير ضمادات'] },
  { name: 'خطة متعددة التخصصات',       services: ['علاج طبيعي', 'تمريض', 'تغذية علاجية'] },
  { name: 'رعاية الجروح والضمادات',    services: ['تغيير ضمادات يومي', 'مراقبة التئام الجروح'] },
  { name: 'إعادة التأهيل الحركي',      services: ['علاج طبيعي', 'تمارين تعافي'] },
  { name: 'الرعاية ما بعد الجراحة',    services: ['مراقبة مستمرة', 'تمريض متخصص', 'دعم نفسي'] },
  { name: 'الرعاية التلطيفية',         services: ['رعاية مسكنة', 'دعم عائلي', 'إدارة الألم'] },
]

const PROVIDERS = [
  'شركة الرعاية المنزلية السعودية',
  'مجموعة رعاية الشرقية',
  'مركز الرياض الطبي المنزلي',
]

// ─── بناء الطلبات ──────────────────────────────────────────────────────────
const BASE_DATE = '2025-01-15'
const CONFIGS = [
  { freq: 9, weeks: 6, status: 'ACTIVE' },
  { freq: 7, weeks: 8, status: 'ACTIVE' },
  { freq: 3, weeks: 4, status: 'ACTIVE' },
  { freq: 5, weeks: 6, status: 'COMPLETED' },
  { freq: 2, weeks: 3, status: 'ACTIVE' },
  { freq: 4, weeks: 5, status: 'CANCELLED' },
]

export const MOCK_REQUESTS_RAW = CONFIGS.map((cfg, i) => {
  const pt  = PATIENTS[i]
  const pl  = PLANS[i]
  const pv  = PROVIDERS[i % 3]
  const id  = `req-00${i + 1}`
  const start = addDays(BASE_DATE, i * 14)
  const end   = addDays(start, cfg.weeks * 7)
  const slots = makeSlots(id, start, cfg.freq, cfg.weeks)

  const total     = slots.length
  const completed = slots.filter(s => s.status === 'COMPLETED').length
  const delayed   = slots.filter(s => s.status === 'DELAYED').length
  const pending   = slots.filter(s => s.status === 'PENDING').length
  const pct       = total > 0 ? Math.round((completed / total) * 100) : 0

  return {
    id,
    external_request_id: `HC-2025-000${i + 1}`,
    external_patient_id: pt.extId,
    patient_name: pt.name,
    patient_age: pt.age,
    patient_gender: pt.gender,
    plan_name: pl.name,
    provider_name: pv,
    status: cfg.status,
    frequency: cfg.freq,
    total_weeks: cfg.weeks,
    start_date: start,
    end_date: end,
    service_count: pl.services.length,
    services: pl.services,
    notes: `ملاحظات الطلب ${i + 1}: متابعة دورية وتقييم أسبوعي`,
    total_slots: total,
    completed_slots: completed,
    delayed_slots: delayed,
    pending_slots: pending,
    completion_pct: pct,
    _slots: slots,
  }
})

// ─── فهرسة سريعة ──────────────────────────────────────────────────────────
const _byId = Object.fromEntries(MOCK_REQUESTS_RAW.map(r => [r.id, r]))
let   _requests = [...MOCK_REQUESTS_RAW]

export const MOCK_SLOTS_MAP = Object.fromEntries(
  MOCK_REQUESTS_RAW.map(r => [r.id, r._slots])
)

export const MOCK_STATS = Object.fromEntries(
  MOCK_REQUESTS_RAW.map(r => [r.id, {
    total_slots: r.total_slots,
    completed_slots: r.completed_slots,
    delayed_slots: r.delayed_slots,
    pending_slots: r.pending_slots,
    completion_pct: r.completion_pct,
  }])
)

// ─── MOCK FUNCTIONS ────────────────────────────────────────────────────────
export function mockListRequests({ status, search, page, limit }) {
  let rows = [..._requests]
  if (status) rows = rows.filter(r => r.status === status)
  if (search) {
    const q = search.toLowerCase()
    rows = rows.filter(r =>
      r.patient_name.includes(q) ||
      r.external_request_id.toLowerCase().includes(q) ||
      r.external_patient_id.toLowerCase().includes(q)
    )
  }
  // delayed filter
  if (status === 'DELAYED') rows = rows.filter(r => r.delayed_slots > 0)

  const total = rows.length
  const pages = Math.ceil(total / limit) || 1
  const slice = rows.slice((page - 1) * limit, page * limit)

  return Promise.resolve({ data: slice, total, pages, page })
}

export function mockGetRequest(id) {
  const r = _byId[id]
  if (!r) return Promise.reject(new Error('الطلب غير موجود'))
  return Promise.resolve({ data: r })
}

export function mockGetSlots(requestId) {
  const slots = MOCK_SLOTS_MAP[requestId] || []
  // بناء grid: { weekNumber: { dayOfWeek: [slot, ...] } }
  const grid = {}
  for (const s of slots) {
    if (!grid[s.weekNumber]) grid[s.weekNumber] = {}
    if (!grid[s.weekNumber][s.dayOfWeek]) grid[s.weekNumber][s.dayOfWeek] = []
    grid[s.weekNumber][s.dayOfWeek].push(s)
  }
  const services = _byId[requestId]?.services?.map((name, i) => ({ id: `svc-${i}`, name })) || []
  return Promise.resolve({ data: { grid, services, slots } })
}

export function mockUpdateSlot(slotId, status, notes) {
  // ابحث عن الجلسة في كل الطلبات وحدّثها
  for (const slots of Object.values(MOCK_SLOTS_MAP)) {
    const slot = slots.find(s => s.id === slotId)
    if (slot) {
      slot.status = status
      slot.notes  = notes
      slot.logs.push({ action: 'UPDATE', status, notes, at: new Date().toISOString(), by: 'المشرف' })
      // أعد حساب rollup للطلب
      const req = _byId[slot.requestId]
      if (req) {
        req.completed_slots = slots.filter(s => s.status === 'COMPLETED').length
        req.delayed_slots   = slots.filter(s => s.status === 'DELAYED').length
        req.pending_slots   = slots.filter(s => s.status === 'PENDING').length
        req.completion_pct  = Math.round((req.completed_slots / req.total_slots) * 100)
      }
      break
    }
  }
  return Promise.resolve({ data: { message: 'تم التحديث' } })
}

export function mockSlotLogs(slotId) {
  for (const slots of Object.values(MOCK_SLOTS_MAP)) {
    const slot = slots.find(s => s.id === slotId)
    if (slot) return slot.logs
  }
  return []
}

export function mockCancelRequest(id, reason) {
  if (_byId[id]) {
    _byId[id].status = 'CANCELLED'
    _byId[id].cancel_reason = reason
  }
  return Promise.resolve({ data: { message: 'تم إلغاء الطلب' } })
}

export function mockMarkOverdue() {
  let count = 0
  const now = new Date()
  for (const slots of Object.values(MOCK_SLOTS_MAP)) {
    for (const s of slots) {
      if (s.status === 'PENDING' && new Date(s.date) < now) {
        s.status = 'DELAYED'; count++
      }
    }
  }
  return Promise.resolve({ data: { message: `تم تحديث ${count} جلسة كمتأخرة`, updated: count } })
}

// ─── تصدير عام للاستخدام المباشر ─────────────────────────────────────────
export const MOCK_REQUESTS = MOCK_REQUESTS_RAW
