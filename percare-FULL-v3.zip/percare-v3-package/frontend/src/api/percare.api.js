/**
 * PerCare API Client – طبقة الاتصال بالـ Backend
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * الوضعان المدعومان:
 *   - وضع Mock  (افتراضي): VITE_USE_MOCK=true  ← بيانات وهمية، لا يحتاج سيرفر
 *   - وضع حقيقي:           VITE_USE_MOCK=false  ← يتصل بـ Express/PostgreSQL
 *
 * لتفعيل الاتصال الحقيقي أضف في .env:
 *   VITE_API_BASE_URL=http://localhost:3000/api/percare
 *   VITE_USE_MOCK=false
 */

// ─── تحديد الوضع ──────────────────────────────────────────────────────────
const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false'   // true = بيانات وهمية
const BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api/percare'

// ─── استيراد بيانات Mock (كل الدوال والبيانات) ─────────────────────────────
import {
  MOCK_REQUESTS,
  MOCK_SLOTS_MAP,
  MOCK_STATS,
  mockListRequests,
  mockGetRequest,
  mockGetSlots,
  mockUpdateSlot,
  mockSlotLogs,
  mockCancelRequest,
  mockMarkOverdue,
} from './mockData'

// ─── HTTP Helper ───────────────────────────────────────────────────────────
async function http(method, path, body = null, params = {}) {
  const url = new URL(BASE_URL + path, window.location.origin)
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') url.searchParams.append(k, v)
  })

  // دعم مصادر توكن متعددة (مرونة للدمج مع الداشبورد الرئيسي)
  const token =
    localStorage.getItem('homecare_token') ||
    localStorage.getItem('percare_token') ||
    localStorage.getItem('token') ||
    sessionStorage.getItem('token')

  const opts = {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  }

  const res = await fetch(url.toString(), opts)

  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: `HTTP ${res.status}` }))
    throw new Error(err.message || `HTTP ${res.status}`)
  }
  return res.json()
}

// ══════════════════════════════════════════════════════════════════════════════
// PUBLIC API FUNCTIONS
// ══════════════════════════════════════════════════════════════════════════════

/**
 * قائمة الطلبات مع بحث وفلترة وتصفح صفحات
 * GET /requests?status=&search=&page=&limit=
 */
export async function apiListRequests({ status = '', search = '', page = 1, limit = 20 } = {}) {
  if (USE_MOCK) return mockListRequests({ status, search, page, limit })
  return http('GET', '/requests', null, { status, search, page, limit })
}

/**
 * تفاصيل طلب واحد بمعرّفه
 * GET /requests/:id
 */
export async function apiGetRequest(id) {
  if (USE_MOCK) return mockGetRequest(id)
  return http('GET', `/requests/${id}`)
}

/**
 * الجدول الأسبوعي (slots) لطلب محدد
 * GET /requests/:id/slots
 */
export async function apiGetSlots(requestId) {
  if (USE_MOCK) return mockGetSlots(requestId)
  return http('GET', `/requests/${requestId}/slots`)
}

/**
 * إحصائيات KPI لطلب محدد
 * GET /requests/:id/stats
 */
export async function apiGetStats(requestId) {
  if (USE_MOCK) return { data: MOCK_STATS[requestId] || {} }
  return http('GET', `/requests/${requestId}/stats`)
}

/**
 * تحديث حالة جلسة واحدة
 * PUT /slots/:slotId/status
 */
export async function apiUpdateSlotStatus(slotId, { status, notes = '', performed_by = 'المشرف' }) {
  if (USE_MOCK) return mockUpdateSlot(slotId, status, notes)
  return http('PUT', `/slots/${slotId}/status`, { status, notes, performed_by })
}

/**
 * سجل تدقيق جلسة
 * GET /slots/:slotId/logs
 */
export async function apiGetSlotLogs(slotId) {
  if (USE_MOCK) return { data: { logs: mockSlotLogs(slotId) } }
  return http('GET', `/slots/${slotId}/logs`)
}

/**
 * إلغاء طلب مع سبب
 * POST /requests/:id/cancel
 */
export async function apiCancelRequest(id, reason) {
  if (USE_MOCK) return mockCancelRequest(id, reason)
  return http('POST', `/requests/${id}/cancel`, { reason })
}

/**
 * إعادة حساب الجدول الأسبوعي
 * POST /requests/:id/recalculate
 */
export async function apiRecalculate(id) {
  if (USE_MOCK) return { data: { message: 'تمت إعادة الحساب بنجاح' } }
  return http('POST', `/requests/${id}/recalculate`)
}

/**
 * تشغيل مهمة تحديث الجلسات المتأخرة
 * POST /jobs/mark-overdue
 */
export async function apiMarkOverdue() {
  if (USE_MOCK) return mockMarkOverdue()
  return http('POST', '/jobs/mark-overdue')
}

/**
 * إنشاء طلب جديد
 * POST /requests
 */
export async function apiCreateRequest(data) {
  if (USE_MOCK) return { data: { id: 'req-new-' + Date.now(), ...data, status: 'ACTIVE' } }
  return http('POST', '/requests', data)
}

/**
 * تحديث جماعي للجلسات
 * POST /slots/bulk-update
 */
export async function apiBulkUpdateSlots(updates) {
  if (USE_MOCK) {
    for (const u of updates) await mockUpdateSlot(u.slot_id, u.status, u.notes || '')
    return { data: { updated: updates.length } }
  }
  return http('POST', '/slots/bulk-update', { updates })
}
