import React, { useState, useEffect, useCallback } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import {
  apiGetRequest,
  apiGetSlots,
  apiUpdateSlotStatus,
  apiGetSlotLogs,
  apiCancelRequest,
  apiRecalculate,
} from '../../api/percare.api'
import StatusBadge from '../../components/percare/StatusBadge'
import { PageSpinner } from '../../components/ui/Spinner'
import { useToast } from '../../contexts/ToastContext'

const NAVY     = '#0f2557'
const DAYS_AR  = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']

function fmt(d, opts = {}) {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('ar-SA', { day: 'numeric', month: 'long', year: 'numeric', ...opts })
}

// ─── بطاقة KPI ───────────────────────────────────────────────────────────
function KpiCard({ label, value, icon, color, bgColor }) {
  return (
    <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 flex items-center gap-4">
      <div className="w-12 h-12 rounded-xl flex items-center justify-center text-xl" style={{ background: bgColor + '20' }}>
        <span style={{ color: bgColor }}>{icon}</span>
      </div>
      <div>
        <div className="text-3xl font-black" style={{ color }}>{value ?? '—'}</div>
        <div className="text-xs text-gray-500 mt-0.5 font-medium">{label}</div>
      </div>
    </div>
  )
}

// ─── شارة حالة الجلسة ────────────────────────────────────────────────────
function SlotBadge({ slot, onClick }) {
  const cfg = {
    COMPLETED: { bg: '#dcfce7', text: '#166534', label: 'مكتملة' },
    DELAYED:   { bg: '#fee2e2', text: '#991b1b', label: 'متأخرة' },
    PENDING:   { bg: '#e0e7ff', text: '#3730a3', label: 'معلقة'  },
  }[slot.status] || { bg: '#f3f4f6', text: '#374151', label: slot.status }

  return (
    <button
      onClick={() => onClick && onClick(slot)}
      className="w-full text-right rounded-lg px-2 py-1.5 transition-all hover:opacity-80 hover:shadow-sm mb-1"
      style={{ background: cfg.bg }}
    >
      <div className="text-xs font-bold" style={{ color: cfg.text }}>{slot.time || '—'}</div>
      <div className="text-[10px] font-medium mt-0.5" style={{ color: cfg.text }}>{cfg.label}</div>
    </button>
  )
}

// ─── مودال تحديث الجلسة ──────────────────────────────────────────────────
function SlotModal({ slot, onClose, onSave }) {
  const [status, setStatus] = useState(slot?.status || 'COMPLETED')
  const [notes,  setNotes]  = useState(slot?.notes  || '')
  const [logs,   setLogs]   = useState([])
  const [saving, setSaving] = useState(false)
  const { error } = useToast()

  useEffect(() => {
    if (slot) {
      apiGetSlotLogs(slot.id)
        .then(r => setLogs(r.data?.logs || []))
        .catch(() => {})
    }
  }, [slot])

  const save = async () => {
    setSaving(true)
    try {
      await onSave(slot.id, { status, notes })
      onClose()
    } catch (e) {
      error('فشل التحديث: ' + e.message)
    } finally {
      setSaving(false)
    }
  }

  const STATUS_OPTIONS = [
    { v: 'COMPLETED', l: 'مكتملة',  color: '#166534' },
    { v: 'DELAYED',   l: 'متأخرة',  color: '#991b1b' },
    { v: 'PENDING',   l: 'معلقة',   color: '#3730a3' },
  ]

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" dir="rtl">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold" style={{ color: NAVY }}>تحديث حالة الجلسة</h3>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl font-bold">✕</button>
          </div>
          <p className="text-sm text-gray-500 mt-1">
            {slot?.date && fmt(slot.date)} · {slot?.time}
          </p>
        </div>

        <div className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">الحالة الجديدة</label>
            <div className="grid grid-cols-3 gap-2">
              {STATUS_OPTIONS.map(o => (
                <button
                  key={o.v}
                  onClick={() => setStatus(o.v)}
                  className="py-2.5 rounded-xl text-sm font-bold transition-all border-2"
                  style={{
                    borderColor: status === o.v ? o.color : 'transparent',
                    background: status === o.v ? o.color + '15' : '#f9fafb',
                    color: status === o.v ? o.color : '#6b7280',
                  }}
                >
                  {o.l}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">ملاحظات</label>
            <textarea
              value={notes}
              onChange={e => setNotes(e.target.value)}
              rows={3}
              placeholder="أضف ملاحظة على هذه الجلسة..."
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-200 resize-none"
            />
          </div>

          {logs.length > 0 && (
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">سجل التعديلات</label>
              <div className="max-h-32 overflow-y-auto space-y-1.5">
                {logs.map((log, i) => (
                  <div key={i} className="bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-600 flex items-center gap-2">
                    <span className="text-gray-400">{log.at ? new Date(log.at).toLocaleString('ar-SA') : ''}</span>
                    <span>·</span>
                    <span>{log.status || log.action}</span>
                    {log.notes && <><span>·</span><span className="text-gray-500">{log.notes}</span></>}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-gray-100 flex gap-3">
          <button
            onClick={save}
            disabled={saving}
            className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white transition-all disabled:opacity-50"
            style={{ background: NAVY }}
          >
            {saving ? 'جاري الحفظ...' : 'حفظ التعديل'}
          </button>
          <button onClick={onClose} className="px-6 py-2.5 rounded-xl text-sm font-bold text-gray-700 bg-gray-100 hover:bg-gray-200 transition-all">
            إلغاء
          </button>
        </div>
      </div>
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════════
// الصفحة الرئيسية
// ══════════════════════════════════════════════════════════════════════════════
export default function PerCareRequestDetailsPage() {
  const { id }   = useParams()
  const navigate = useNavigate()
  const toast    = useToast()

  const [request,      setRequest]      = useState(null)
  const [grid,         setGrid]         = useState({})
  const [loading,      setLoading]      = useState(true)
  const [slotsLoading, setSlotsLoading] = useState(false)
  const [selectedSlot, setSelectedSlot] = useState(null)
  const [showCancel,   setShowCancel]   = useState(false)
  const [cancelReason, setCancelReason] = useState('')
  const [cancelling,   setCancelling]   = useState(false)
  const [recalcLoading,setRecalcLoading]= useState(false)

  // ── تحميل الطلب ──────────────────────────────────────────────────────
  const loadRequest = useCallback(async () => {
    try {
      const r = await apiGetRequest(id)
      setRequest(r.data)
    } catch (e) {
      toast.error('فشل تحميل الطلب: ' + e.message)
    }
  }, [id])

  // ── تحميل الجدول ─────────────────────────────────────────────────────
  const loadSlots = useCallback(async () => {
    setSlotsLoading(true)
    try {
      const r = await apiGetSlots(id)
      setGrid(r.data?.grid || {})
    } catch (e) {
      toast.error('فشل تحميل الجدول')
    } finally {
      setSlotsLoading(false)
    }
  }, [id])

  useEffect(() => {
    setLoading(true)
    Promise.all([loadRequest(), loadSlots()]).finally(() => setLoading(false))
  }, [id])

  // ── تحديث جلسة ────────────────────────────────────────────────────────
  const handleSlotSave = async (slotId, data) => {
    await apiUpdateSlotStatus(slotId, data)
    toast.success('✅ تم تحديث حالة الجلسة')
    await Promise.all([loadRequest(), loadSlots()])
  }

  // ── إلغاء الطلب ───────────────────────────────────────────────────────
  const handleCancel = async () => {
    if (!cancelReason.trim()) { toast.error('يرجى إدخال سبب الإلغاء'); return }
    setCancelling(true)
    try {
      await apiCancelRequest(id, cancelReason)
      toast.success('تم إلغاء الطلب')
      setShowCancel(false)
      await loadRequest()
    } catch (e) {
      toast.error(e.message)
    } finally {
      setCancelling(false)
    }
  }

  // ── إعادة الحساب ──────────────────────────────────────────────────────
  const handleRecalculate = async () => {
    setRecalcLoading(true)
    try {
      await apiRecalculate(id)
      toast.success('تمت إعادة حساب الجدول')
      await Promise.all([loadRequest(), loadSlots()])
    } catch (e) {
      toast.error(e.message)
    } finally {
      setRecalcLoading(false)
    }
  }

  // ── Loading ───────────────────────────────────────────────────────────
  if (loading) return <PageSpinner />

  if (!request) return (
    <div className="p-10 text-center">
      <div className="text-5xl mb-4">❌</div>
      <p className="text-gray-600 font-semibold text-lg">الطلب غير موجود</p>
      <button onClick={() => navigate('/percare/requests')} className="mt-4 text-blue-600 hover:underline text-sm">
        ← العودة للقائمة
      </button>
    </div>
  )

  const req = request
  const initials = req.patient_name?.split(' ').slice(0, 2).map(w => w[0]).join('') || '؟'
  const pct = parseFloat(req.completion_pct || 0)
  const barColor = pct >= 75 ? '#10b981' : pct >= 40 ? '#f59e0b' : '#ef4444'
  const weeks = Object.keys(grid).map(Number).sort((a, b) => a - b)

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl">

      {/* ══ Hero Banner ════════════════════════════════════════════════════ */}
      <div
        className="relative overflow-hidden"
        style={{ background: `linear-gradient(135deg, ${NAVY} 0%, #1e3a8a 60%, #0ea5e9 100%)` }}
      >
        {/* زخرفة خلفية */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-64 h-64 bg-white rounded-full -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-80 h-80 bg-white rounded-full translate-x-1/3 translate-y-1/3" />
        </div>

        <div className="relative z-10 px-6 pt-5 pb-6">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-white/70 text-xs mb-5">
            <Link to="/dashboard" className="hover:text-white transition-colors">الرعاية المنزلية</Link>
            <span>/</span>
            <Link to="/percare/requests" className="hover:text-white transition-colors">PerCare</Link>
            <span>/</span>
            <Link to="/percare/requests" className="hover:text-white transition-colors">الطلبات</Link>
            <span>/</span>
            <span className="text-white font-bold">{req.external_request_id}</span>
          </nav>

          {/* محتوى الـ Banner */}
          <div className="flex items-center gap-5">
            {/* Avatar */}
            <div className="w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-white text-2xl font-black border border-white/30 flex-shrink-0">
              {initials}
            </div>

            {/* المعلومات الأساسية */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3 flex-wrap">
                <h1 className="text-2xl font-black text-white truncate">{req.patient_name}</h1>
                <span
                  className="text-xs font-bold px-3 py-1 rounded-full border"
                  style={{
                    background: req.status === 'ACTIVE' ? '#22c55e30' : req.status === 'COMPLETED' ? '#3b82f630' : '#ef444430',
                    borderColor: req.status === 'ACTIVE' ? '#22c55e60' : req.status === 'COMPLETED' ? '#3b82f660' : '#ef444460',
                    color: req.status === 'ACTIVE' ? '#bbf7d0' : req.status === 'COMPLETED' ? '#bfdbfe' : '#fecaca',
                  }}
                >
                  {req.status === 'ACTIVE' ? 'نشط' : req.status === 'COMPLETED' ? 'مكتمل' : req.status === 'CANCELLED' ? 'ملغي' : req.status}
                </span>
              </div>

              <div className="flex items-center gap-4 mt-2 text-white/80 text-sm flex-wrap">
                <span className="flex items-center gap-1.5">
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  {req.external_request_id}
                </span>
                <span className="flex items-center gap-1.5">
                  <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  {fmt(req.start_date)} — {fmt(req.end_date)}
                </span>
                {req.provider_name && (
                  <span className="flex items-center gap-1.5">
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                    {req.provider_name}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* شريط التقدم في الـ Banner */}
          <div className="mt-5 bg-white/10 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2 text-white text-sm">
              <span className="font-semibold">نسبة الإنجاز</span>
              <span className="font-black text-lg">{pct.toFixed(0)}%</span>
            </div>
            <div className="h-2.5 bg-white/20 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{ width: `${Math.min(pct, 100)}%`, background: barColor }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* ══ محتوى الصفحة ═══════════════════════════════════════════════════ */}
      <div className="px-6 py-6 space-y-6 pb-28">

        {/* بطاقات KPI */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <KpiCard label="إجمالي الجلسات" value={req.total_slots}     icon="📅" color={NAVY}       bgColor={NAVY} />
          <KpiCard label="مكتملة"          value={req.completed_slots} icon="✅" color="#059669"    bgColor="#059669" />
          <KpiCard label="متأخرة"          value={req.delayed_slots}   icon="⚠️" color="#dc2626"    bgColor="#dc2626" />
          <KpiCard label="معلقة"           value={req.pending_slots}   icon="⏳" color="#7c3aed"    bgColor="#7c3aed" />
        </div>

        {/* تفاصيل الخطة */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
          <h2 className="text-base font-black mb-5 flex items-center gap-2" style={{ color: NAVY }}>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
            </svg>
            تفاصيل الخطة
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-5">
            {[
              { label: 'اسم الخطة',    value: req.plan_name,      icon: '📋' },
              { label: 'المزود',        value: req.provider_name,  icon: '🏥' },
              { label: 'تاريخ البدء',  value: fmt(req.start_date),icon: '📅' },
              { label: 'تاريخ الانتهاء',value: fmt(req.end_date), icon: '🏁' },
              { label: 'التكرار الأسبوعي', value: `${req.frequency || '—'} جلسة/أسبوع`, icon: '🔄' },
              { label: 'المدة الكلية', value: `${req.total_weeks || '—'} أسبوع`, icon: '⏱️' },
            ].map(({ label, value, icon }) => (
              <div key={label} className="bg-gray-50 rounded-xl p-4">
                <div className="text-xs text-gray-400 font-medium mb-1 flex items-center gap-1.5">
                  <span>{icon}</span>{label}
                </div>
                <div className="text-sm font-bold" style={{ color: NAVY }}>{value || '—'}</div>
              </div>
            ))}
          </div>

          {req.notes && (
            <div className="mt-4 bg-amber-50 border border-amber-100 rounded-xl p-4">
              <div className="text-xs text-amber-600 font-bold mb-1">📝 ملاحظات</div>
              <div className="text-sm text-amber-800">{req.notes}</div>
            </div>
          )}

          {req.services?.length > 0 && (
            <div className="mt-4">
              <div className="text-xs text-gray-400 font-bold mb-2 uppercase tracking-wide">الخدمات المضمنة</div>
              <div className="flex flex-wrap gap-2">
                {req.services.map((s, i) => (
                  <span key={i} className="bg-blue-50 text-blue-700 text-xs font-semibold px-3 py-1.5 rounded-full">
                    {typeof s === 'string' ? s : s.name}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* الجدول الأسبوعي */}
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h2 className="text-base font-black flex items-center gap-2" style={{ color: NAVY }}>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              الجدول الأسبوعي
            </h2>
            {/* مفتاح الألوان */}
            <div className="flex items-center gap-3 text-xs">
              {[
                { label: 'مكتملة', bg: '#dcfce7', text: '#166534' },
                { label: 'متأخرة', bg: '#fee2e2', text: '#991b1b' },
                { label: 'معلقة',  bg: '#e0e7ff', text: '#3730a3' },
              ].map(c => (
                <div key={c.label} className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-sm" style={{ background: c.bg, border: `1px solid ${c.text}30` }} />
                  <span className="text-gray-500">{c.label}</span>
                </div>
              ))}
            </div>
          </div>

          {slotsLoading ? (
            <div className="py-16 text-center text-gray-400">جاري تحميل الجدول...</div>
          ) : weeks.length === 0 ? (
            <div className="py-16 text-center text-gray-400">لا توجد جلسات محددة</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full" style={{ minWidth: '640px' }}>
                <thead>
                  <tr className="border-b border-gray-100" style={{ background: '#f0f4ff' }}>
                    <th className="px-4 py-3 text-right text-xs font-bold w-24" style={{ color: NAVY }}>الأسبوع</th>
                    {DAYS_AR.map(d => (
                      <th key={d} className="px-2 py-3 text-center text-xs font-bold" style={{ color: NAVY }}>{d}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {weeks.map(weekNum => (
                    <tr key={weekNum} className="border-b border-gray-50 hover:bg-blue-50/20 transition-colors">
                      <td className="px-4 py-3">
                        <span className="text-xs font-bold px-2.5 py-1 rounded-full" style={{ background: '#e8edf7', color: NAVY }}>
                          أسبوع {weekNum}
                        </span>
                      </td>
                      {DAYS_AR.map((_, dayIdx) => {
                        const daySlots = grid[weekNum]?.[dayIdx] || []
                        return (
                          <td key={dayIdx} className="px-2 py-2 align-top min-w-[90px]">
                            {daySlots.length > 0
                              ? daySlots.map(slot => (
                                  <SlotBadge
                                    key={slot.id}
                                    slot={slot}
                                    onClick={req.status !== 'CANCELLED' ? setSelectedSlot : null}
                                  />
                                ))
                              : <div className="h-10" />
                            }
                          </td>
                        )
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* ══ Footer الإجراءات ═══════════════════════════════════════════════ */}
      {req.status !== 'CANCELLED' && (
        <div className="fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-sm border-t border-gray-200 z-40 px-6 py-4">
          <div className="flex items-center gap-3 max-w-screen-lg mx-auto justify-end flex-wrap">
            <button
              onClick={() => navigate('/percare/requests')}
              className="px-5 py-2.5 rounded-xl text-sm font-bold text-gray-600 bg-gray-100 hover:bg-gray-200 transition-all flex items-center gap-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              القائمة
            </button>
            <button
              onClick={handleRecalculate}
              disabled={recalcLoading}
              className="px-5 py-2.5 rounded-xl text-sm font-bold text-white transition-all disabled:opacity-50 flex items-center gap-2"
              style={{ background: '#1e3a8a' }}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              {recalcLoading ? 'جاري...' : 'إعادة الحساب'}
            </button>
            <button
              onClick={() => setShowCancel(true)}
              className="px-5 py-2.5 rounded-xl text-sm font-bold text-white bg-red-600 hover:bg-red-700 transition-all flex items-center gap-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
              إلغاء الطلب
            </button>
          </div>
        </div>
      )}

      {/* ══ مودال تحديث الجلسة ═════════════════════════════════════════════ */}
      {selectedSlot && (
        <SlotModal
          slot={selectedSlot}
          onClose={() => setSelectedSlot(null)}
          onSave={handleSlotSave}
        />
      )}

      {/* ══ مودال إلغاء الطلب ══════════════════════════════════════════════ */}
      {showCancel && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
            <h3 className="text-lg font-black text-red-700 mb-2">⚠️ تأكيد إلغاء الطلب</h3>
            <p className="text-sm text-gray-600 mb-4">
              سيتم إلغاء الطلب <strong>{req.external_request_id}</strong> للمريض <strong>{req.patient_name}</strong>. هذا الإجراء لا يمكن التراجع عنه.
            </p>
            <textarea
              value={cancelReason}
              onChange={e => setCancelReason(e.target.value)}
              rows={3}
              placeholder="سبب الإلغاء (مطلوب)..."
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-red-200 resize-none mb-4"
            />
            <div className="flex gap-3">
              <button
                onClick={handleCancel}
                disabled={cancelling}
                className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white bg-red-600 hover:bg-red-700 transition-all disabled:opacity-50"
              >
                {cancelling ? 'جاري الإلغاء...' : 'تأكيد الإلغاء'}
              </button>
              <button
                onClick={() => { setShowCancel(false); setCancelReason('') }}
                className="px-6 py-2.5 rounded-xl text-sm font-bold text-gray-700 bg-gray-100 hover:bg-gray-200 transition-all"
              >
                تراجع
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
