import React, { useState, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { apiListRequests, apiMarkOverdue } from '../../api/percare.api'
import { useDebounce } from '../../hooks/useDebounce'
import StatusBadge from '../../components/percare/StatusBadge'
import { PageSpinner } from '../../components/ui/Spinner'
import { useToast } from '../../contexts/ToastContext'

// ─── ثوابت ────────────────────────────────────────────────────────────────
const STATUS_TABS = [
  { v: '',          l: 'الكل',    color: 'text-gray-700',    bg: 'bg-gray-100' },
  { v: 'ACTIVE',    l: 'نشطة',    color: 'text-blue-700',    bg: 'bg-blue-100' },
  { v: 'COMPLETED', l: 'مكتملة',  color: 'text-emerald-700', bg: 'bg-emerald-100' },
  { v: 'CANCELLED', l: 'ملغاة',   color: 'text-red-700',     bg: 'bg-red-100' },
  { v: 'DELAYED',   l: 'متأخرة',  color: 'text-amber-700',   bg: 'bg-amber-100' },
]

const NAVY = '#0f2557'

function fmt(d) {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('ar-SA', { day: 'numeric', month: 'short', year: 'numeric' })
}

// ─── صف الجدول ────────────────────────────────────────────────────────────
function RequestRow({ req, onClick }) {
  const pct = parseFloat(req.completion_pct || 0)
  const barColor = pct >= 75 ? '#10b981' : pct >= 40 ? '#f59e0b' : '#ef4444'

  return (
    <tr
      onClick={() => onClick(req.id)}
      className="hover:bg-blue-50/50 cursor-pointer transition-colors border-b border-gray-100 group"
    >
      {/* المريض */}
      <td className="px-5 py-4">
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-bold flex-shrink-0"
            style={{ background: `linear-gradient(135deg, ${NAVY}, #1e3a8a)` }}
          >
            {req.patient_name?.charAt(0) || '؟'}
          </div>
          <div>
            <div className="font-bold text-gray-800 text-sm group-hover:text-blue-700 transition-colors">
              {req.patient_name}
            </div>
            <div className="text-xs text-gray-400 mt-0.5">{req.external_patient_id}</div>
          </div>
        </div>
      </td>

      {/* رقم الطلب */}
      <td className="px-4 py-4">
        <span
          className="text-xs font-bold px-2.5 py-1 rounded-full"
          style={{ background: '#e8edf7', color: NAVY }}
        >
          {req.external_request_id}
        </span>
      </td>

      {/* الفترة */}
      <td className="px-4 py-4 text-sm text-gray-600 whitespace-nowrap">
        <div className="flex items-center gap-1">
          <svg className="w-3.5 h-3.5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          <span>{fmt(req.start_date)}</span>
          <span className="text-gray-300">—</span>
          <span>{fmt(req.end_date)}</span>
        </div>
      </td>

      {/* الخدمات */}
      <td className="px-4 py-4 text-center">
        <span className="bg-indigo-50 text-indigo-700 text-xs font-bold px-2.5 py-1 rounded-full">
          {req.service_count || 0}
        </span>
      </td>

      {/* الجلسات */}
      <td className="px-4 py-4 text-center font-bold text-gray-700 text-sm">{req.total_slots || 0}</td>

      {/* مكتمل */}
      <td className="px-4 py-4 text-center font-bold text-emerald-600 text-sm">{req.completed_slots || 0}</td>

      {/* متأخر */}
      <td className="px-4 py-4 text-center">
        {(req.delayed_slots || 0) > 0
          ? <span className="bg-red-100 text-red-700 text-xs font-bold px-2.5 py-1 rounded-full">{req.delayed_slots}!</span>
          : <span className="text-gray-300 text-sm">—</span>
        }
      </td>

      {/* التقدم */}
      <td className="px-4 py-4">
        <div className="flex items-center gap-2 min-w-[110px]">
          <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all"
              style={{ width: `${Math.min(pct, 100)}%`, backgroundColor: barColor }}
            />
          </div>
          <span className="text-xs font-bold text-gray-600 min-w-[38px] text-left">{pct.toFixed(0)}%</span>
        </div>
      </td>

      {/* الحالة */}
      <td className="px-4 py-4"><StatusBadge status={req.status} /></td>

      {/* سهم */}
      <td className="px-4 py-4">
        <svg className="w-5 h-5 text-gray-300 group-hover:text-blue-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
      </td>
    </tr>
  )
}

// ─── بطاقة KPI ─────────────────────────────────────────────────────────────
function KpiCard({ label, value, icon, color, bg }) {
  return (
    <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 flex items-center gap-4">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl ${bg}`}>
        {icon}
      </div>
      <div>
        <div className={`text-2xl font-black ${color}`}>{value}</div>
        <div className="text-xs text-gray-500 mt-0.5 font-medium">{label}</div>
      </div>
    </div>
  )
}

// ─── الصفحة الرئيسية ────────────────────────────────────────────────────────
export default function PerCareRequestsListPage() {
  const navigate = useNavigate()
  const toast    = useToast()

  const [data,       setData]       = useState([])
  const [total,      setTotal]      = useState(0)
  const [pages,      setPages]      = useState(1)
  const [loading,    setLoading]    = useState(true)
  const [page,       setPage]       = useState(1)
  const [status,     setStatus]     = useState('')
  const [search,     setSearch]     = useState('')
  const [jobLoading, setJobLoading] = useState(false)
  const dSearch = useDebounce(search, 400)

  // ── تحميل البيانات ─────────────────────────────────────────────────────
  const load = useCallback(async () => {
    setLoading(true)
    try {
      const res = await apiListRequests({ status, search: dSearch, page, limit: 20 })
      setData(res.data || [])
      setTotal(res.total || 0)
      setPages(res.pages || 1)
    } catch (e) {
      toast.error('فشل تحميل الطلبات: ' + e.message)
    } finally {
      setLoading(false)
    }
  }, [status, dSearch, page])

  useEffect(() => { load() }, [load])
  useEffect(() => { setPage(1) }, [status, dSearch])

  // ── مهمة التأخير ───────────────────────────────────────────────────────
  const runJob = async () => {
    setJobLoading(true)
    try {
      const r = await apiMarkOverdue()
      toast.success(r.data?.message || 'تم تشغيل مهمة التأخير')
      load()
    } catch (e) {
      toast.error('فشل: ' + e.message)
    } finally {
      setJobLoading(false)
    }
  }

  // ── حساب إحصائيات الـ KPI ────────────────────────────────────────────
  // نحسبها من البيانات المحملة إذا كانت متوفرة
  const kpi = {
    total:     total,
    active:    data.filter(r => r.status === 'ACTIVE').length,
    completed: data.filter(r => r.status === 'COMPLETED').length,
    delayed:   data.filter(r => (r.delayed_slots || 0) > 0).length,
  }

  return (
    <div className="p-6 min-h-screen bg-white" dir="rtl">

      {/* ── رأس الصفحة ──────────────────────────────────────────────── */}
      <div className="mb-6">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl font-black text-gray-900">
              طلبات <span style={{ color: NAVY }}>PerCare</span>
            </h1>
            <p className="text-gray-500 text-sm mt-1">
              إجمالي طلبات الرعاية المنزلية المجدولة · {total} طلب
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={runJob}
              disabled={jobLoading}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white transition-all disabled:opacity-50"
              style={{ background: NAVY }}
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {jobLoading ? 'جاري...' : 'تحديث المتأخرات'}
            </button>
            <button
              onClick={load}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-gray-700 bg-gray-100 hover:bg-gray-200 transition-all"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              تحديث
            </button>
          </div>
        </div>
      </div>

      {/* ── بطاقات KPI ─────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <KpiCard label="إجمالي الطلبات" value={total}        icon="📋" color="text-gray-800"    bg="bg-gray-100" />
        <KpiCard label="نشطة"           value={kpi.active}   icon="⚡" color="text-blue-700"    bg="bg-blue-100" />
        <KpiCard label="مكتملة"         value={kpi.completed}icon="✅" color="text-emerald-700" bg="bg-emerald-100" />
        <KpiCard label="بها تأخير"      value={kpi.delayed}  icon="⚠️" color="text-red-700"     bg="bg-red-100" />
      </div>

      {/* ── شريط الفلترة والبحث ───────────────────────────────────────── */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 mb-5 flex items-center gap-4 flex-wrap">
        {/* بحث */}
        <div className="flex-1 min-w-[220px] relative">
          <svg className="absolute top-1/2 -translate-y-1/2 right-3 w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            placeholder="البحث بالاسم أو رقم الطلب..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            dir="rtl"
            className="w-full pr-10 pl-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-200 bg-gray-50"
          />
        </div>

        {/* تبويبات الحالة */}
        <div className="flex bg-gray-100 rounded-xl p-1 gap-1 flex-wrap">
          {STATUS_TABS.map(t => (
            <button
              key={t.v}
              onClick={() => setStatus(t.v)}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                status === t.v ? `bg-white shadow-sm ${t.color}` : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {t.l}
            </button>
          ))}
        </div>
      </div>

      {/* ── الجدول ─────────────────────────────────────────────────────── */}
      {loading ? (
        <PageSpinner />
      ) : data.length === 0 ? (
        <div className="py-24 text-center bg-white rounded-2xl border border-gray-100">
          <div className="text-5xl mb-4">🔍</div>
          <p className="text-gray-500 font-medium text-lg">لا توجد طلبات مطابقة</p>
          <p className="text-gray-400 text-sm mt-2">جرّب تغيير معايير البحث أو الفلترة</p>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm" style={{ minWidth: '900px' }} dir="rtl">
              <thead>
                <tr style={{ background: '#f0f4ff' }}>
                  {['المريض', 'رقم الطلب', 'الفترة', 'الخدمات', 'الجلسات', 'مكتمل', 'متأخر', 'التقدم', 'الحالة', ''].map(h => (
                    <th
                      key={h}
                      className="px-4 py-3.5 text-right text-xs font-bold uppercase tracking-wide whitespace-nowrap first:pr-5"
                      style={{ color: NAVY }}
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.map(req => (
                  <RequestRow
                    key={req.id}
                    req={req}
                    onClick={id => navigate(`/percare/requests/${id}`)}
                  />
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── تصفح الصفحات ───────────────────────────────────────────────── */}
      {pages > 1 && (
        <div className="flex items-center justify-center gap-3 mt-6">
          <button
            onClick={() => setPage(p => p - 1)}
            disabled={page <= 1}
            className="px-4 py-2 rounded-xl text-sm font-semibold bg-gray-100 text-gray-700 hover:bg-gray-200 disabled:opacity-40 transition-all"
          >
            → السابق
          </button>
          <span className="text-sm text-gray-600 font-medium bg-white border border-gray-200 px-4 py-2 rounded-xl">
            صفحة {page} من {pages}
          </span>
          <button
            onClick={() => setPage(p => p + 1)}
            disabled={page >= pages}
            className="px-4 py-2 rounded-xl text-sm font-semibold bg-gray-100 text-gray-700 hover:bg-gray-200 disabled:opacity-40 transition-all"
          >
            التالي ←
          </button>
        </div>
      )}
    </div>
  )
}
