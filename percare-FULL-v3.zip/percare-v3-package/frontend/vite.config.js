import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: { host: '0.0.0.0', port: 5173 },
  preview: {
    host: '0.0.0.0',
    port: 4173,
    allowedHosts: ['all', '4173-i5x2pk00yo2ev0iromz5s.e2b.dev']
  }
})
